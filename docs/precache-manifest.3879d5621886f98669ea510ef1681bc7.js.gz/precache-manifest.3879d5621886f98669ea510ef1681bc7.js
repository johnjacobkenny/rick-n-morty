self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e3b6694e1344dbc6b23ead6179050202",
    "url": "/rick-n-morty/index.html"
  },
  {
    "revision": "6125c97e402cc522acac",
    "url": "/rick-n-morty/static/css/main.7238c92c.chunk.css"
  },
  {
    "revision": "7495f0456e33b3d800cf",
    "url": "/rick-n-morty/static/js/2.13487666.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/rick-n-morty/static/js/2.13487666.chunk.js.LICENSE"
  },
  {
    "revision": "6125c97e402cc522acac",
    "url": "/rick-n-morty/static/js/main.ace807bd.chunk.js"
  },
  {
    "revision": "56e953a55d770ed21b0e",
    "url": "/rick-n-morty/static/js/runtime-main.4d53ad1e.js"
  },
  {
    "revision": "5a59177ef7138d50b3f5e3eb5b86b34a",
    "url": "/rick-n-morty/static/media/rnm.5a59177e.png"
  }
]);