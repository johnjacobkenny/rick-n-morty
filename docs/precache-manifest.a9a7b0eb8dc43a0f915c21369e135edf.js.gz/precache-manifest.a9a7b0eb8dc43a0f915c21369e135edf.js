self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ae8c9af3de10fac5fc6fa369b263d686",
    "url": "/rick-n-morty/index.html"
  },
  {
    "revision": "5286c71c3b4ddf8cc5b8",
    "url": "/rick-n-morty/static/css/main.fc26da06.chunk.css"
  },
  {
    "revision": "a404eac6c460fba6f6f4",
    "url": "/rick-n-morty/static/js/2.373aefc0.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/rick-n-morty/static/js/2.373aefc0.chunk.js.LICENSE"
  },
  {
    "revision": "5286c71c3b4ddf8cc5b8",
    "url": "/rick-n-morty/static/js/main.4b530fec.chunk.js"
  },
  {
    "revision": "56e953a55d770ed21b0e",
    "url": "/rick-n-morty/static/js/runtime-main.4d53ad1e.js"
  },
  {
    "revision": "381cc717713c9bdd01ce937aa7ebf0e5",
    "url": "/rick-n-morty/static/media/emptyState.381cc717.png"
  },
  {
    "revision": "5a59177ef7138d50b3f5e3eb5b86b34a",
    "url": "/rick-n-morty/static/media/rnm.5a59177e.png"
  }
]);