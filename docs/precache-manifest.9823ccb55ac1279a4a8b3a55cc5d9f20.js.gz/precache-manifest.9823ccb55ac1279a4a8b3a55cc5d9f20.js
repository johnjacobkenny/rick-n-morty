self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8ac1438b96c2f2b8838f42f399379006",
    "url": "/rick-n-morty/index.html"
  },
  {
    "revision": "099d3aa1799e595c6e19",
    "url": "/rick-n-morty/static/css/main.fc26da06.chunk.css"
  },
  {
    "revision": "a404eac6c460fba6f6f4",
    "url": "/rick-n-morty/static/js/2.373aefc0.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/rick-n-morty/static/js/2.373aefc0.chunk.js.LICENSE"
  },
  {
    "revision": "099d3aa1799e595c6e19",
    "url": "/rick-n-morty/static/js/main.2151d4f6.chunk.js"
  },
  {
    "revision": "56e953a55d770ed21b0e",
    "url": "/rick-n-morty/static/js/runtime-main.4d53ad1e.js"
  },
  {
    "revision": "381cc717713c9bdd01ce937aa7ebf0e5",
    "url": "/rick-n-morty/static/media/emptyState.381cc717.png"
  },
  {
    "revision": "5a59177ef7138d50b3f5e3eb5b86b34a",
    "url": "/rick-n-morty/static/media/rnm.5a59177e.png"
  }
]);